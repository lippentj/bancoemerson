﻿using AppBoteco.Classes;
using botequinhoApp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace AppBoteco
{
    public partial class FrmProduto : Form
    {
        public FrmProduto()
        {
            InitializeComponent();
        }

        private void FrmProduto_Load(object sender, EventArgs e)
        {

            FrmProduto produto = new FrmProduto();
            List<Produto> produtos = produto.listaproduto;
            dgvProduto.DataSource = produtos;
            btnEditar.Enabled = false;
            btnExcluir.Enabled = false;
            this.ActiveControl = txtNome;
        }

        private void btnFechar_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnInserir_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNome.Text) || string.IsNullOrWhiteSpace(cbxTipo.Text) || string.IsNullOrWhiteSpace(txtQuantidade.Text) || string.IsNullOrWhiteSpace(txtPreco.Text)

)
            {
                MessageBox.Show("Por favor, preencha todos os campos!", "Atenção", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                Produto produto = new Produto();
                if (produto.RegistroRepetido(txtNome.Text, cbxTipo.Text) == true)
                {
                    MessageBox.Show("Produto já existe em nossa base de dados!", "Produto Repetido", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtNome.Text = "";
                    cbxTipo.Text = "";
                    txtQuantidade.Text = "";
                    txtPreco.Text = "";
                    return;
                }
                else
                {
                    produto.Inserir(txtNome.Text, cbxTipo.Text, int.Parse(txtQuantidade.Text), v2: float.Parse(txtPreco.Text));
                    MessageBox.Show("Cliente Inserido com sucesso!", "Inserção", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    List<Produto> produtos = produto.listaproduto();
                    dgvProduto.DataSource = produtos;
                    txtNome.Text = "";
                    cbxTipo.Text = "";
                    txtQuantidade.Text = "";
                    txtPreco.Text = "";
                    this.txtNome.Focus();
                }
            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message, "Erro - Inserção", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
